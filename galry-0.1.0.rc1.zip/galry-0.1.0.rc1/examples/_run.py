"""Run all examples successively."""
from galry import run_all_scripts
run_all_scripts(ignore=['gallery.py'])
