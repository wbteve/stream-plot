Galry's Gallery
===============

Screenshots
-----------

![Multiple plots](https://raw.github.com/rossant/galry/master/images/thumbnails/img0.jpg)
![Multiple bar plots](https://raw.github.com/rossant/galry/master/images/thumbnails/img1.jpg)
![Raster plot](https://raw.github.com/rossant/galry/master/images/thumbnails/img2.jpg)
![Dynamic graph layout](https://raw.github.com/rossant/galry/master/images/thumbnails/img3.jpg)
![Sprite points](https://raw.github.com/rossant/galry/master/images/thumbnails/img4.jpg)
![Dynamic fractal](https://raw.github.com/rossant/galry/master/images/thumbnails/img5.jpg)
![Modern art](https://raw.github.com/rossant/galry/master/images/thumbnails/img6.jpg)
![Graph](https://raw.github.com/rossant/galry/master/images/thumbnails/img7.jpg)
![Image](https://raw.github.com/rossant/galry/master/images/thumbnails/img8.jpg)
![GPU-based image filtering](https://raw.github.com/rossant/galry/master/images/thumbnails/img9.jpg)
![Particle system](https://raw.github.com/rossant/galry/master/images/thumbnails/img10.jpg)
![3D mesh](https://raw.github.com/rossant/galry/master/images/thumbnails/img11.jpg)
![Cellular automata](https://raw.github.com/rossant/galry/master/images/thumbnails/img12.jpg)
![2D surface](https://raw.github.com/rossant/galry/master/images/thumbnails/img13.jpg)


Videos
------

[Click here to see demos on Youtube.](http://www.youtube.com/watch?v=Nv4aNR4Gi6w&list=PLyxVOal96D3zFYTYNco1DIVANAQ5122f1)

